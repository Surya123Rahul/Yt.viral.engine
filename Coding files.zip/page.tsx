'use client';

import { useState, useEffect } from 'react';
import axios from 'axios';

// API Configuration
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

interface Voice {
  id: string;
  name: string;
  category: string;
  description: string;
}

interface ProjectStatus {
  project_id: string;
  status: string;
  progress: number;
  current_step: string;
  video_url?: string;
  error?: string;
}

export default function Home() {
  const [topic, setTopic] = useState('');
  const [voices, setVoices] = useState<Voice[]>([]);
  const [selectedVoice, setSelectedVoice] = useState('');
  const [duration, setDuration] = useState(60);
  const [style, setStyle] = useState('engaging');
  const [isGenerating, setIsGenerating] = useState(false);
  const [projectStatus, setProjectStatus] = useState<ProjectStatus | null>(null);
  const [videoUrl, setVideoUrl] = useState('');

  // Fetch available voices on mount
  useEffect(() => {
    fetchVoices();
  }, []);

  // Poll project status when generating
  useEffect(() => {
    if (projectStatus && projectStatus.status !== 'completed' && projectStatus.status !== 'failed') {
      const interval = setInterval(() => {
        fetchProjectStatus(projectStatus.project_id);
      }, 2000); // Poll every 2 seconds

      return () => clearInterval(interval);
    }
  }, [projectStatus]);

  const fetchVoices = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/api/voices`);
      setVoices(response.data);
      if (response.data.length > 0) {
        setSelectedVoice(response.data[0].id);
      }
    } catch (error) {
      console.error('Error fetching voices:', error);
    }
  };

  const fetchProjectStatus = async (projectId: string) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/api/project/${projectId}`);
      setProjectStatus(response.data);

      if (response.data.status === 'completed' && response.data.video_url) {
        setVideoUrl(`${API_BASE_URL}${response.data.video_url}`);
        setIsGenerating(false);
      } else if (response.data.status === 'failed') {
        setIsGenerating(false);
      }
    } catch (error) {
      console.error('Error fetching project status:', error);
    }
  };

  const handleGenerate = async () => {
    if (!topic.trim()) {
      alert('Please enter a video topic');
      return;
    }

    if (!selectedVoice) {
      alert('Please select a voice');
      return;
    }

    setIsGenerating(true);
    setProjectStatus(null);
    setVideoUrl('');

    try {
      const response = await axios.post(`${API_BASE_URL}/api/generate`, {
        topic: topic,
        voice_id: selectedVoice,
        duration: duration,
        style: style,
      });

      setProjectStatus(response.data);
    } catch (error) {
      console.error('Error generating video:', error);
      alert('Failed to start video generation');
      setIsGenerating(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-black text-white">
      {/* Header */}
      <header className="bg-black/50 backdrop-blur-sm border-b border-purple-500/30">
        <div className="container mx-auto px-6 py-4">
          <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-pink-600 bg-clip-text text-transparent">
            🎬 The Viral Engine
          </h1>
          <p className="text-gray-400 text-sm mt-1">AI-Powered Video Creation Studio</p>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-12">
        <div className="max-w-4xl mx-auto">
          {/* Input Section */}
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-8 border border-purple-500/20 shadow-2xl mb-8">
            <h2 className="text-2xl font-semibold mb-6 flex items-center">
              <span className="mr-3">✨</span>
              Create Your Viral Video
            </h2>

            {/* Video Topic Input */}
            <div className="mb-6">
              <label className="block text-sm font-medium mb-2 text-gray-300">
                Video Topic
              </label>
              <input
                type="text"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="e.g., 10 Mind-Blowing AI Facts, Top Travel Destinations 2025"
                className="w-full px-4 py-3 bg-gray-900 border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-white placeholder-gray-500"
                disabled={isGenerating}
              />
            </div>

            {/* Voice Selection */}
            <div className="mb-6">
              <label className="block text-sm font-medium mb-2 text-gray-300">
                Voice Selection
              </label>
              <select
                value={selectedVoice}
                onChange={(e) => setSelectedVoice(e.target.value)}
                className="w-full px-4 py-3 bg-gray-900 border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-white"
                disabled={isGenerating}
              >
                {voices.map((voice) => (
                  <option key={voice.id} value={voice.id}>
                    {voice.name} ({voice.category})
                  </option>
                ))}
              </select>
            </div>

            {/* Duration and Style */}
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div>
                <label className="block text-sm font-medium mb-2 text-gray-300">
                  Duration (seconds)
                </label>
                <input
                  type="number"
                  value={duration}
                  onChange={(e) => setDuration(parseInt(e.target.value))}
                  min="15"
                  max="60"
                  className="w-full px-4 py-3 bg-gray-900 border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-white"
                  disabled={isGenerating}
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2 text-gray-300">
                  Style
                </label>
                <select
                  value={style}
                  onChange={(e) => setStyle(e.target.value)}
                  className="w-full px-4 py-3 bg-gray-900 border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-white"
                  disabled={isGenerating}
                >
                  <option value="engaging">Engaging</option>
                  <option value="educational">Educational</option>
                  <option value="funny">Funny</option>
                  <option value="dramatic">Dramatic</option>
                </select>
              </div>
            </div>

            {/* Generate Button */}
            <button
              onClick={handleGenerate}
              disabled={isGenerating}
              className={`w-full py-4 rounded-lg font-semibold text-lg transition-all transform ${
                isGenerating
                  ? 'bg-gray-700 cursor-not-allowed'
                  : 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 hover:scale-105 shadow-lg'
              }`}
            >
              {isGenerating ? '⏳ Generating...' : '🚀 Generate Video'}
            </button>
          </div>

          {/* Progress Section */}
          {projectStatus && (
            <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-8 border border-purple-500/20 shadow-2xl mb-8">
              <h3 className="text-xl font-semibold mb-4">Generation Progress</h3>

              {/* Progress Bar */}
              <div className="mb-4">
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-gray-400">{projectStatus.current_step}</span>
                  <span className="text-purple-400 font-semibold">{projectStatus.progress}%</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-4 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-purple-500 to-pink-500 transition-all duration-500 ease-out rounded-full"
                    style={{ width: `${projectStatus.progress}%` }}
                  />
                </div>
              </div>

              {/* Status */}
              <div className="text-center">
                <span
                  className={`inline-block px-4 py-2 rounded-full text-sm font-medium ${
                    projectStatus.status === 'completed'
                      ? 'bg-green-500/20 text-green-400'
                      : projectStatus.status === 'failed'
                      ? 'bg-red-500/20 text-red-400'
                      : 'bg-blue-500/20 text-blue-400'
                  }`}
                >
                  {projectStatus.status === 'completed' ? '✅ Complete!' : 
                   projectStatus.status === 'failed' ? '❌ Failed' : 
                   '⏳ Processing...'}
                </span>
              </div>

              {projectStatus.error && (
                <div className="mt-4 p-4 bg-red-500/10 border border-red-500/30 rounded-lg">
                  <p className="text-red-400 text-sm">{projectStatus.error}</p>
                </div>
              )}
            </div>
          )}

          {/* Video Preview */}
          {videoUrl && (
            <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-8 border border-purple-500/20 shadow-2xl">
              <h3 className="text-xl font-semibold mb-4">🎉 Your Video is Ready!</h3>
              <div className="aspect-[9/16] max-w-md mx-auto bg-black rounded-lg overflow-hidden">
                <video
                  controls
                  className="w-full h-full"
                  src={videoUrl}
                >
                  Your browser does not support the video tag.
                </video>
              </div>
              <div className="mt-6 text-center">
                <a
                  href={videoUrl}
                  download
                  className="inline-block px-8 py-3 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 rounded-lg font-semibold transition-all transform hover:scale-105"
                >
                  📥 Download Video
                </a>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-black/50 backdrop-blur-sm border-t border-purple-500/30 py-6 mt-12">
        <div className="container mx-auto px-6 text-center text-gray-400 text-sm">
          <p>Powered by Claude, ElevenLabs, Flux.1, and Runway Gen-3</p>
        </div>
      </footer>
    </div>
  );
}
