"""
The Viral Engine - Main FastAPI Application
Backend API for automated AI video generation
"""
from fastapi import FastAPI, HTTPException, BackgroundTasks, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import uuid
from datetime import datetime
import asyncio

from app.config import settings
from app.services.openrouter_client import openrouter_client
from app.services.voice_service import elevenlabs_service
from app.services.video_processor import video_processor

# Create FastAPI app
app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="AI-powered viral video generation platform"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory storage for projects (replace with database in production)
projects_db = {}


# Pydantic Models
class VideoGenerationRequest(BaseModel):
    topic: str
    voice_id: str
    duration: int = 60
    style: str = "engaging"
    resolution: tuple = (1080, 1920)


class ProjectStatus(BaseModel):
    project_id: str
    status: str  # pending, generating_script, generating_audio, generating_visuals, processing_video, completed, failed
    progress: int  # 0-100
    current_step: str
    created_at: datetime
    video_url: Optional[str] = None
    error: Optional[str] = None


class VoiceInfo(BaseModel):
    id: str
    name: str
    category: str
    description: str


# Root endpoint
@app.get("/")
async def root():
    """Health check endpoint"""
    return {
        "app": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "status": "running"
    }


# Get available voices
@app.get("/api/voices", response_model=List[VoiceInfo])
async def get_voices():
    """
    Fetch available voices from ElevenLabs
    """
    try:
        voices = await elevenlabs_service.get_available_voices()
        return voices
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch voices: {str(e)}")


# Generate video endpoint
@app.post("/api/generate", response_model=ProjectStatus)
async def generate_video(
    request: VideoGenerationRequest,
    background_tasks: BackgroundTasks
):
    """
    Start video generation process
    Returns project ID for tracking progress
    """
    # Create new project
    project_id = str(uuid.uuid4())
    
    project = {
        "project_id": project_id,
        "status": "pending",
        "progress": 0,
        "current_step": "Initializing",
        "created_at": datetime.now(),
        "request": request.dict(),
        "video_url": None,
        "error": None
    }
    
    projects_db[project_id] = project
    
    # Start background task
    background_tasks.add_task(
        process_video_generation,
        project_id,
        request
    )
    
    return ProjectStatus(**project)


# Get project status
@app.get("/api/project/{project_id}", response_model=ProjectStatus)
async def get_project_status(project_id: str):
    """
    Get current status of video generation project
    """
    if project_id not in projects_db:
        raise HTTPException(status_code=404, detail="Project not found")
    
    project = projects_db[project_id]
    return ProjectStatus(**project)


# Download video
@app.get("/api/download/{project_id}")
async def download_video(project_id: str):
    """
    Download completed video file
    """
    if project_id not in projects_db:
        raise HTTPException(status_code=404, detail="Project not found")
    
    project = projects_db[project_id]
    
    if project["status"] != "completed":
        raise HTTPException(status_code=400, detail="Video not ready yet")
    
    video_path = project.get("video_path")
    if not video_path:
        raise HTTPException(status_code=404, detail="Video file not found")
    
    return FileResponse(
        video_path,
        media_type="video/mp4",
        filename=f"viral_video_{project_id}.mp4"
    )


async def process_video_generation(project_id: str, request: VideoGenerationRequest):
    """
    Background task to handle complete video generation pipeline
    """
    project = projects_db[project_id]
    
    try:
        # Step 1: Generate Script (20% progress)
        project["status"] = "generating_script"
        project["current_step"] = "Generating viral script with AI"
        project["progress"] = 10
        
        script = await openrouter_client.generate_script(
            topic=request.topic,
            duration=request.duration,
            style=request.style
        )
        
        project["script"] = script
        project["progress"] = 20
        
        # Step 2: Generate Audio for each scene (40% progress)
        project["status"] = "generating_audio"
        project["current_step"] = "Creating voiceover with ElevenLabs"
        project["progress"] = 25
        
        audio_dir = f"{settings.TEMP_DIR}/{project_id}/audio"
        audio_files = await elevenlabs_service.generate_audio_for_scenes(
            scenes=script.get("scenes", []),
            voice_id=request.voice_id,
            output_dir=audio_dir
        )
        
        project["audio_files"] = audio_files
        project["progress"] = 40
        
        # Step 3: Generate visuals for each scene (70% progress)
        project["status"] = "generating_visuals"
        project["current_step"] = "Creating AI-generated visuals"
        
        video_clips = []
        scenes = script.get("scenes", [])
        
        for idx, scene in enumerate(scenes):
            project["progress"] = 40 + (30 * (idx + 1) / len(scenes))
            
            # Generate image using Flux.1
            visual_desc = scene.get("visual_description", "")
            image_result = await openrouter_client.generate_image(
                prompt=visual_desc,
                width=request.resolution[0],
                height=request.resolution[1]
            )
            
            # Download image (implementation depends on OpenRouter response format)
            image_path = f"{settings.TEMP_DIR}/{project_id}/images/scene_{idx + 1}.png"
            # TODO: Download image from URL returned by API
            
            # Convert image to video clip
            video_path = f"{settings.TEMP_DIR}/{project_id}/clips/scene_{idx + 1}.mp4"
            video_processor.create_video_from_image(
                image_path=image_path,
                duration=scene.get("duration", 10),
                output_path=video_path,
                resolution=request.resolution
            )
            
            video_clips.append(video_path)
        
        project["video_clips"] = video_clips
        project["progress"] = 70
        
        # Step 4: Process and merge everything (100% progress)
        project["status"] = "processing_video"
        project["current_step"] = "Merging clips and adding subtitles"
        project["progress"] = 80
        
        final_video_path = await video_processor.create_final_video(
            scenes=scenes,
            video_clips=video_clips,
            audio_files=audio_files,
            project_id=project_id
        )
        
        project["video_path"] = final_video_path
        project["video_url"] = f"/api/download/{project_id}"
        project["progress"] = 100
        project["status"] = "completed"
        project["current_step"] = "Video ready!"
        
    except Exception as e:
        project["status"] = "failed"
        project["error"] = str(e)
        project["current_step"] = f"Error: {str(e)}"
        print(f"Error generating video for project {project_id}: {e}")


# List all projects (for dashboard)
@app.get("/api/projects")
async def list_projects():
    """
    List all video generation projects
    """
    return [
        ProjectStatus(**project)
        for project in projects_db.values()
    ]


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host=settings.API_HOST,
        port=settings.API_PORT,
        reload=settings.DEBUG
    )
